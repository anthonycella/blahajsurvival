module information {
	requires java.desktop;
}