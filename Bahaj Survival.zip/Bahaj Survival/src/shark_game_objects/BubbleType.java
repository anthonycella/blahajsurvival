package shark_game_objects;

public enum BubbleType {
	SMALL_BUBBLE, MEDIUM_BUBBLE, LARGE_BUBBLE
}
